# Search algorithm visulaizer

This is a search algorithm visulaizer GUI which was built using Tkinter.I used frames for UI and canvas for creating rectangle bars to represent data.
This Code has linearsearch and binary search.If the data is not sorted then it uses bubble sort to sort the data so that data can be used to find the value using binary search.
To give error messages I used popup function in PYTHON_PROJECT.PY
<img width="797" alt="Screenshot 2022-10-20 at 3 32 12 PM" src="https://user-images.githubusercontent.com/96576837/196919667-26ea8ab8-0e4d-4ada-8b0c-388d3fbb8b54.png">
<img width="796" alt="Screenshot 2022-10-20 at 3 32 24 PM" src="https://user-images.githubusercontent.com/96576837/196919696-2c82906c-ecdd-460c-923c-d44ad9be613c.png">
